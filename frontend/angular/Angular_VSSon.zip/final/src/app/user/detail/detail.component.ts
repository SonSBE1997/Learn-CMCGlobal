import { Component, OnInit } from '@angular/core';
import { User } from '../user.interface';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { mergeMap } from 'rxjs/operators';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss']
})
export class DetailComponent implements OnInit {
  user: User;
  constructor(
    private http: HttpClient,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit() {
    this.activatedRoute.paramMap
      .pipe(
        mergeMap(pm => {
          const id = pm.get('id');
          return this.http.get<User>(`http://localhost:3000/users/${id}`);
        })
      )
      .subscribe(u => (this.user = u));
  }
}
