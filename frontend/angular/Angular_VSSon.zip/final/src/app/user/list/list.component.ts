import { Component, OnInit } from '@angular/core';
import { User } from '../user.interface';
import { HttpClient } from '@angular/common/http';
import { mergeMap } from 'rxjs/operators';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {
  users: User[] = [];
  constructor(private http: HttpClient) {}
  displayedColumns: string[] = ['id', 'name', 'email', 'photo', 'action'];
  ngOnInit() {
    this.http.get<User[]>('http://localhost:3000/users').subscribe(user => {
      this.users = user;
    });
  }

  deleteUser(id: string) {
    const result = window.confirm('Do u wanna delete this record');
    if (result) {
      this.http
        .delete(`http://localhost:3000/users/${id}`)
        .pipe(
          mergeMap(() => this.http.get<User[]>('http://localhost:3000/users'))
        )
        .subscribe(user => {
          this.users = user;
          console.log(this.users);
        });
    }
  }
}
