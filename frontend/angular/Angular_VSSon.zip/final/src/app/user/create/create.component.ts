import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { v4 } from 'uuid';
import { User } from '../user.interface';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss']
})
export class CreateComponent implements OnInit {
  userFrm: FormGroup;
  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router
  ) {}

  ngOnInit() {
    this.userFrm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(5)]],
      email: ['', [Validators.required, Validators.email]],
      photo: ['', [Validators.required]]
    });
  }

  onSubmit() {
    const data = this.userFrm.value;
    if (this.userFrm.valid) {
      const user: User = {
        id: v4(),
        ...data
      };

      this.http
        .post('http://localhost:3000/users', user)
        .subscribe(success => this.router.navigateByUrl('/users'));
    }
  }
}
