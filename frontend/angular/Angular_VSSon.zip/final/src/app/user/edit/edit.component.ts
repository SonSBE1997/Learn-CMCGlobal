import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { User } from '../user.interface';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { mergeMap } from 'rxjs/operators';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']
})
export class EditComponent implements OnInit {
  userFrm: FormGroup;
  id: string;
  emitter = new EventEmitter<Boolean>();
  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit() {
    this.userFrm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(5)]],
      email: ['', [Validators.required, Validators.email]],
      photo: ['', [Validators.required]]
    });
    this.activatedRoute.paramMap
      .pipe(
        mergeMap(pm => {
          const id = pm.get('id');
          return this.http.get<User>(`http://localhost:3000/users/${id}`);
        })
      )
      .subscribe(u => {
        this.id = u.id;
        this.userFrm.patchValue(u);
      });
  }

  onSubmit() {
    const data = this.userFrm.value;
    if (this.userFrm.valid) {
      this.http
        .patch(`http://localhost:3000/users/${this.id}`, data)
        .subscribe(success => {
          console.log(success);
          this.router.navigateByUrl('/users');
        });
    }
  }
}
