import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-exam',
  templateUrl: './detail-exam.component.html',
  styleUrls: ['./detail-exam.component.css']
})
export class DetailExamComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
