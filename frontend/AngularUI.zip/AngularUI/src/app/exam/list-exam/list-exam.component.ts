import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-exam',
  templateUrl: './list-exam.component.html',
  styleUrls: ['./list-exam.component.css']
})
export class ListExamComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
