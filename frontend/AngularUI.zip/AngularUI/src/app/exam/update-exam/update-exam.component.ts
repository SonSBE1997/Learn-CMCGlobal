import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-exam',
  templateUrl: './update-exam.component.html',
  styleUrls: ['./update-exam.component.css']
})
export class UpdateExamComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
