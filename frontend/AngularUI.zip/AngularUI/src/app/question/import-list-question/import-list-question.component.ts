import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-import-list-question',
  templateUrl: './import-list-question.component.html',
  styleUrls: ['./import-list-question.component.css']
})
export class ImportListQuestionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
